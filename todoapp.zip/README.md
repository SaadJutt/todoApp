# angular-9-role-based-authorization-example

Angular 9 - Role Based Authorization Example

For tutorial and live demo see https://jasonwatmore.com/post/2020/05/15/angular-9-role-based-authorization-tutorial-with-example
